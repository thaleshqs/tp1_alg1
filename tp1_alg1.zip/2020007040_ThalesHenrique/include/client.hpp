#ifndef CLIENT_HPP
#define CLIENT_HPP
#include <iostream>

using namespace std;

class Client {
//operators:
friend std::istream & operator >> (std::istream & input, Client & object);
friend bool operator < (Client const & A, Client const & B);
	
private:
	//attributes:
	int age, x, y, id;
	string state, payment;
	bool available = true;
	float ticket;
	int shopIndex;//the shop the client is assigned to
    int insertPos;//index at which the client was inserted
public:
	//setters
	void setInsertPos(int i);
	void setId(int id);
    void setTicket();
	void setAvailable(bool x);
	void setShopIndex(int i);
	//getters
    int getInsertPos();
    int getShopIndex();
    bool isAvailable();
    int getId();
    int calculateDist(int a, int b);
};

//implementing operators
inline bool operator < (Client const & A, Client const & B){
	if (A.ticket != B.ticket)
		return A.ticket > B.ticket;
	else
		return A.id < B.id; 
}

inline std::istream & operator >> (std::istream & input, Client & object) {
    input >> object.age >> object.state >> object.payment >> object.x >> object.y;
    return input;
}

#endif