#ifndef SHOP_HPP
#define SHOP_HPP
#include <vector>
#include <utility>
#include <iostream>

using namespace std;


class Shop {
//cin operator
friend istream& operator >> (istream&, Shop&);

private:
	//attributes
    int x, y, storage, id, currStorage;
    int clientIndex = 0;
	int clientCount = 0;
	bool insideStack = true;
public:
	vector<pair<int,bool>> assignedClients;
	void print();
	//setters:
	void setId(int id);
	void setClient(int x);
    void removeClient(int pos);
    void updateClientIndex();
	void setStackStatus(bool);
    //getters:
	int getClientCount();
	int getStorage();
    int getCurrStorage();
	int getClientIndex();
    int getId();
    int getX();
    int getY();
	bool isInStack();
	
    
    
};
//implementing >> operator
inline istream& operator >> (istream& input, Shop& object) {
    input >> object.storage >> object.x >> object.y;
    object.currStorage = object.storage;
    return input;
}

#endif