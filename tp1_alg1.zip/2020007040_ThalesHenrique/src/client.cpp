#include "client.hpp"
#include <iostream>

using namespace std;

//setters

//set index of insertion
void Client::setInsertPos(int i) {
    this->insertPos = i;
}

//set client id
void Client::setId(int id) {
    this->id = id;
}

//set ticket
void Client::setTicket() {
    //calculate the state score:
    float stateScore = -1;
    if (this->state == "MG") {
        stateScore = 0;
    } else if (this->state == "PR") {
        stateScore = 10;
    } else if (this->state == "SP") {
        stateScore = 20;
    } else if (this->state == "SC") {
        stateScore = 30;
    } else if (this->state == "RJ") {
        stateScore = 40;
    } else if (this->state == "RN") {
        stateScore = 50;
    } else if (this->state == "RS") {
        stateScore = 60;
    }

    //calculate payment score:
    float paymentScore = -1;
    if (this->payment == "DINHEIRO") {
        paymentScore = 1;
    } else if (this->payment == "DEBITO") {
        paymentScore = 2;
    } else if (this->payment == "CREDITO") {
        paymentScore = 3;
    }

    //calculate ticket:
    this->ticket = abs(60 - this->age) + stateScore;
    this->ticket /= paymentScore;
}

//self-explanatory
void Client::setAvailable(bool x) {
	this->available = x;
}

//set the index of the shop
void Client::setShopIndex(int i) {
	this->shopIndex = i;
}

//getters

//return insert pos
int Client::getInsertPos() {
    return this->insertPos;
}

//return shop index
int Client::getShopIndex() {
    return this->shopIndex;
}

//return availability status
bool Client::isAvailable() {
    return this->available;
}

//return client id
int Client::getId() {
    return this->id;
}

//return distance
int Client::calculateDist(int a, int b) {
    int dist = max(abs(this->x - a), abs(this->y - b));
    return dist;
}