#include <bits/stdc++.h>
#include "shop.hpp"
#include "client.hpp"

using namespace std;

int main()
{
    //grid
    int n, m;
    cin >> n >> m;
    
    //shops
    int numShops; cin >> numShops; 
    Shop shopList[numShops];
    stack<int> freeShops; //indexes of available shops
    for (int i = 0;i < numShops;i++) {
        //i-th shop:
        cin >> shopList[i];
        shopList[i].setId(i);
        freeShops.push(i);
    }
    
    //clients
    int numClients; cin >> numClients;
    Client clientList[numClients];
    for (int i = 0;i < numClients;i++) {
        //i-th client:
        cin >> clientList[i];
        clientList[i].setId(i);
        clientList[i].setTicket();
    }
    
    //sort clients:
    sort(clientList, clientList + numClients);

    //algorithm:
    while (!freeShops.empty()) {
        int currShop = freeShops.top(); //index of the current shop 
        int desiredClient = shopList[currShop].getClientIndex(); //index of the client that will receive an offer
        int currStorage = shopList[currShop].getCurrStorage(); //number of spots left in the shop
		stack<int> rivals; //shops that will go back into the stack
        
        while (desiredClient < numClients &&  currStorage > 0) {
            if (clientList[desiredClient].isAvailable()) {
                //match the client to the shop:
                clientList[desiredClient].setAvailable(false);
                clientList[desiredClient].setShopIndex(currShop);
                clientList[desiredClient].setInsertPos(shopList[currShop].getClientCount());
                shopList[currShop].setClient(clientList[desiredClient].getId());
            } else {//the client is already matched
                //index and distance of the rival shop
                int rivalShop = clientList[desiredClient].getShopIndex();
                int rivalDist = clientList[desiredClient].calculateDist(shopList[rivalShop].getX(), shopList[rivalShop].getY());
                //distance of the current shop
                int currShopDist = clientList[desiredClient].calculateDist(shopList[currShop].getX(), shopList[currShop].getY());
                
                //compare distances; if necessary, make a new arrangement
                if ((currShopDist < rivalDist) || ((currShopDist == rivalDist) && (currShop < rivalShop))) {
                    //remove client from previous shop
                    shopList[rivalShop].removeClient(clientList[desiredClient].getInsertPos()); 
                    //match the client to current shop
                    clientList[desiredClient].setShopIndex(currShop);
                    clientList[desiredClient].setInsertPos(shopList[currShop].getClientCount());
                    shopList[currShop].setClient(clientList[desiredClient].getId());
                    //push the other shop back into the stack
					if (!shopList[rivalShop].isInStack() && shopList[rivalShop].getClientIndex() < numClients) {
						//this is an optimization
						//don't insert duplicates
						shopList[rivalShop].setStackStatus(true);
						rivals.push(rivalShop);
					}
                } 
            }
            
            //update variables
            shopList[currShop].updateClientIndex();
            desiredClient = shopList[currShop].getClientIndex();
            currStorage = shopList[currShop].getCurrStorage();
        }
        
        
        //remove the current shop from the stack:
        freeShops.pop();
		shopList[currShop].setStackStatus(false);
        
        //push the other shops into the stack
        while (!rivals.empty()) {
			freeShops.push(rivals.top());
			rivals.pop();
		}
    }
    
    //output:
	for (int i = 0;i < numShops;i++) {
        //i-th shop:
        shopList[i].print();
    }

    return 0;
}