#include <iostream>
#include "shop.hpp"

using namespace std;

//print the result using iterators
void Shop::print() {
	cout << this->id << endl;
	bool printed = true;
	int n = this->storage;
	for (auto it = this->assignedClients.begin();it != this->assignedClients.end();++it) {
		if (printed && it->second) {
			cout << it->first;
			printed = false;
			n--;
		} else if (it->second) {
			cout << " " << it->first;
			n--;
		}
		
		if (n == this->currStorage)
			break;
	}
	cout << endl;
}

//setters:

//set shop id
void Shop::setId(int id) {
    this->id = id;

}

//assign client to a shop
void Shop::setClient(int x) {
    this->assignedClients.push_back(make_pair(x, true));
    this->currStorage--;
    this->clientCount++;
}

//"remove" client from the assigned shop
void Shop::removeClient(int pos) {
    this->assignedClients[pos].second = false; //flag
    this->currStorage++;
}

//update the client index pointer
void Shop::updateClientIndex() {
    this->clientIndex++;
}

//decide if the shop should be in the stack
void Shop::setStackStatus(bool status) {
	this->insideStack = status;
}

//getters:

//return the index of the last client
//assigned to the shop
int Shop::getClientCount() {
	return this->clientCount;
}

//return maximum storage
int Shop::getStorage() {
    return this->storage;
}

//return current storage
int Shop::getCurrStorage() {
    return this->currStorage;
}

//return shop id
int Shop::getId() {
    return this->id;
}

//return index of the client
//which would receive the next proposal
int Shop::getClientIndex() {
    return this->clientIndex;
}

//return x coordinate
int Shop::getX() {
    return this->x;
}

//return y coordinate
int Shop::getY() {
    return this->y;
}

//self-explanatory
bool Shop::isInStack() {
	return this->insideStack;
}